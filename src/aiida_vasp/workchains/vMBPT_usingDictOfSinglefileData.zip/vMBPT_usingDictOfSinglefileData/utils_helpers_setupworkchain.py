# -*- coding: utf-8 -*-
from xml.etree import cElementTree as ET
import numpy as np
import os
from scipy.optimize import curve_fit
from pymatgen.io.vasp.outputs import Vasprun , BSVasprun
import warnings
from aiida import orm
from aiida.common.extendeddicts import AttributeDict
from aiida.orm import Code, Bool, Str, Int, Dict, Float , KpointsData , RemoteData , FolderData



##[Preliminar definitions] Python functions and scripts
class Helpers_setup_Workchain :
    """
    This module provides a collection of helper functions used to construct the
    input dictionary required by the `VaspmBSEInitScriptWorkChain`.
    It does NOT run calculations, does NOT submit processes.
    It ONLY prepares correctly-typed inputs and derived parameters
 
    
    [1] INPUTS REQUIRED BY THE HELPER FUNCTIONS:
    [Str : vasprun_path] path on local disk of vasprun.xml reference G0W0 calculation (on disk) 
            -> used to extract the G0W0 gap for the interpolation 
               + dielectric function information for the model
    [Str : potential_family] a POTCAR family in the AiiDA database
    [pymatgen Structure obj] a Pymatgen structure (POSCAR)
    [dict : setup_cluster] a user-provided configuration for the cluster
    [dict : slurm] a user-provided SLURM configuration for the submission calculation

    [2] ASSUMPTIONS MADE BY THE HELPERS
    - The reference GW folder contains: vasprun.xml.3 - OUTCAR 
    - POTCAR families are correctly imported into AiiDA
    - The cluster configuration dictionary contains valid fields:
          account, qos, partition, mem_kb_per_task
    - pymatgen structure is fully parsed from POSCAR

    [3] AN OVERVIEW OF WHAT VaspmBSEInitScriptWorkChain requires
    The workchain VaspmBSEInitScriptWorkChain requires the following inputs:
      ├── structure                   (StructureData)    ← NOT provided by helper functions
      ├── kpoints                     (KpointsData)      ← NOT provided by helper functions
      |        these two can be construicted in the main calling script by 
      |        pymatgen_structure = pcs.Structure.from_file( os.path.join( arg_inputs['PATH_REFERENCEGW'],'POSCAR') )
      |        inputs.structure   = structure.StructureData( pymatgen_structure=pymatgen_structure )
      |        inputs.kpoints = KpointsData() ; inputs.kpoints.set_kpoints_mesh( [..] )
      ├── code                        (Code)             ← Provided by _build_slurm_options
      ├── options                     (Dict)             ← Provided by _build_slurm_options
      ├── potential_family            (Str)              ← From _build_potential_mapping
      ├── potential_mapping           (Dict)             ← From _build_potential_mapping
      │
      ├── ns_parameters
      │     ├── encut                 (Float)    [optional - NOT provided by helper functions]
      │     ├── nbands                (Int)      [optional - NOT provided by helper functions]
      │     ├── magnetic_moment_onsite (Dict)    [optional - NOT provided by helper functions]
      │     ├── ibse                  (Int)      [optional - NOT provided by helper functions]
      │     └── kpar                  (Int)      [optional - NOT provided by helper functions]
      │
      ├── ns_interpolation
      │     ├── local_initscript           (SinglefileData) [OPTIONAL — not provided
      │     ├── G0W0_reference             (RemoteData)     ← from _build_interpolation_inputs
      │     └── nbandsgw_to_interpolate    (Int)            ← from _build_interpolation_inputs
      │     └── remote_gw_reference_folder (RemoteData)     (not used)
      │     └── local_gw_reference_fold    (Str)            ← from _build_interpolation_inputs
      │     └── gw_reference_filename      (Str)            ← from _build_interpolation_inputs
      ├── ns_BSE
      │     ├── static_inverse_diel  (Float)    ← from _build_bse_inputs
      │     ├── screening_parameter   (Float)   ← from _build_bse_inputs
      │     ├── G0W0_gap              (Float)   ← from _build_bse_inputs
      │     ├── optical_energy_window (Float)   ← from _build_bse_inputs (default value) OR user
      │     ├── OMEGAMAX              (Float)   [optional override]
      │     ├── NBANDSV               (Int)     [optional override]
      │     └── NBANDSO               (Int)     [optional override]
      """

    # -------------------------------------------------------------------------
    #[1] Extract dielectric screening parameters from epsilon_diag in vasprun.xml
    @staticmethod
    def _estimate_parameters_from_epsilon_diag( vasprun_path ):
        # Internal helper to parse <v> entries ------- #
        # Taken straight from aiida-vasp internal parser.
        def _convert_array2D_f(entry, dim):  # pylint: disable=C0103
                data = None
                if entry is not None:
                    data = np.zeros((len(entry), dim), dtype='double')
                for index, element in enumerate(entry):
                    try:
                        data[index] = np.fromstring(element.text, sep=' ')
                    except ValueError as err:
                            print("ERRORE ERRORE ERRORE")
                return data
        
        # Parse XML
        vasprun = ET.parse( vasprun_path )
        vasprun_ep_diag_ET = vasprun.findall('.//varray[@name="epsilon_diag"]/v')
        vasprun_ep_diag    = np.asarray(_convert_array2D_f(vasprun_ep_diag_ET, 2))
       
        # Extract arrays - the x are the |G|, the y are the diagonal epsilon value eps(|G|)
        x = vasprun_ep_diag[:, 0]
        y = vasprun_ep_diag[:, 1]
        invepsilonatlowestg = vasprun_ep_diag[ np.argmin( vasprun_ep_diag[:,0] ) , 1]
        init_vals = [1.26]

        # Fit exponential dielectric model - the model is the one used for the VASP model-BSE
        def modelDiel(x,a1 , eps_lowestG=invepsilonatlowestg):
        	return 1 - (1-eps_lowestG)*np.exp( -x**2 / (4*a1**2)  )   
        
        #best_val , covar = optimize.curve_fit(modelDiel, x, y, p0=init_vals)
        best_val , covar = curve_fit(modelDiel, x, y, p0=init_vals)
        return [ invepsilonatlowestg , best_val[0] ]


    # -------------------------------------------------------------------------
    #[2] Extract NBANDSGW from vasprun.xml
    @staticmethod
    def _extract_NBANDSGW ( vasprun_path ):
        """
        Read NBANDSGW from vasprun.xml using pymatgen.
        
        Returns
        -------
        int
            Number of GW bands used in the preceding G0W0 calculation.
        
        Notes
        -----
        This requires a valid vasprun.xml.X produced by VASP's GW step.
        """
        from pymatgen.io.vasp.outputs import Vasprun
        return Vasprun(vasprun_path).parameters['NBANDSGW']


    # -------------------------------------------------------------------------
    #[3] Extract G0W0 band gap using pymatgen
    @staticmethod
    def _extract_gap ( vasprun_path ):
        from pymatgen.io.vasp.outputs import BSVasprun
        from pymatgen.electronic_structure.core import Spin

        BSV     = BSVasprun( vasprun_path )
        BSV_bs  = BSV.get_band_structure()
        BSV_gap = BSV_bs.get_band_gap()['energy']
        return BSV_gap  


    # -------------------------------------------------------------------------
    #[4] Build SLURM options + Code node based on cluster type (cpu/gpu)
    @staticmethod
    def _build_slurm_options( setup_cluster: dict , setup_slurmcalc: dict ) -> tuple[Dict, str]:
        """
        Create an AiiDA Dict of scheduler options and return the selected code string.

        Parameters
        ----------
        setup_cluster : dict
            Dict of cluster setups for 'cpu' and 'gpu', e.g.:
            { 'cpu': {'code': 'vasp@localhost', 'account': 'cin_staff',
                      'qos': 'boost_qos_dbg', 'partition': 'boost_usr_prod',
                      'mem_kb_per_task': 130000000},
              'gpu': {...}         }

        setup_slurmcalc : dict
            Dict with SLURM run settings:
            {'num_nodes': 1, 'ntasks-per-node': 4,
             'are_gpu_available': True, 'time_in_h': 10}

        Returns
        -------
        (Dict, str)
            The AiiDA Dict node with scheduler options and the selected code string.
        """

        # Choose cluster type (gpu or cpu)
        if setup_slurmcalc.get('are_gpu_available', False):
            cluster = setup_cluster['gpu']
        else:
            cluster = setup_cluster['cpu']

        # Extract core info
        code_string = cluster['code']
        
        # Compose options
        options = AttributeDict()
        options.account   = cluster.get('account', 'cin_staff')
        options.qos       = cluster.get('qos', '')
        options.partition = cluster.get('partition', '')
        
        
        tasks_per_node  = int(setup_slurmcalc.get('ntasks-per-node', 1))
        mem_kb_per_task = int(cluster.get('mem_kb_per_task', 1024000))
        options.resources = { 'num_machines': int(setup_slurmcalc.get('num_nodes', 1)) ,
                              'num_mpiprocs_per_machine':tasks_per_node                }
        options.max_wallclock_seconds = int( int(setup_slurmcalc.get('time_in_h', 1)) * 3600 )
        options.max_memory_kb = int( mem_kb_per_task * tasks_per_node )
        #Code in aiida.schedulers.plugins.slurm  https://aiida.readthedocs.io/projects/aiida-core/en/stable/_modules/aiida/schedulers/plugins/slurm.html
        #if job_tmpl.max_memory_kb is not None:
        #    physical_memory_kb = int(job_tmpl.max_memory_kb)
        #    lines.append(f'#SBATCH --mem={physical_memory_kb // 1024}')
        #if job_tmpl.custom_scheduler_commands:
        #    lines.append(job_tmpl.custom_scheduler_commands
            
        if setup_slurmcalc.get('are_gpu_available', False):
            options.custom_scheduler_commands = f"#SBATCH --gres=gpu:{tasks_per_node}"

        # Build AiiDA objects
        code_node      = Code.get_from_string(code_string)
        computer_label = code_string.split("@")[1]
        options_node   = Dict(dict=options)

        return code_node, computer_label, options_node

    # -------------------------------------------------------------------------
    #[5] Build POTCAR mapping (element → POTCAR label)
    @staticmethod
    def _build_potential_mapping( potential_family : str , pymatgen_structure,
                                  flag_prefer_GW: bool = True     ) -> dict[str, str]:
        """
        Construct a POTCAR mapping dictionary {element: potcar_name} based on
        the elements in the given structure and the available POTCARs in the family.
    
        Priority rules:
          - If flag_prefer_GW = True:
              prefer _GW  >  _sv_GW  >  _d_GW  >  plain _GW  >  _sv  >  _d  >  plain
          - If flag_prefer_GW = False:
              prefer _sv  >  _d  >  plain  >  _sv_GW  >  _d_GW  >  _GW
    
        Parameters
        ----------
        potential_family : str
            Label of the POTCAR family (e.g. "PBE.54").
        pymatgen_structure : pymatgen.Structure
            Structure whose elements are used to build the mapping.
        flag_prefer_GW : bool, optional
            Whether to prioritize _GW potentials (default: True).
    
        Returns
        -------
        dict[str, str]
            Mapping between element symbol and POTCAR name.
        """
    
        # Load POTCAR family
        import aiida_vasp.data.potcar
        potcar_group = aiida_vasp.data.potcar.PotcarGroup.collection.get(label=potential_family)
        potcar_dict = {node.element: node.full_name for node in potcar_group.nodes}
    
        # Build mapping
        potential_mapping = {}
        for el in pymatgen_structure.elements:
            elname = str(el)
    
            # Collect all potcars for this element (some families contain variants)
            candidates = [name for elem, name in potcar_dict.items() if elem == elname]
            if not candidates:
                raise ValueError(f"No POTCAR found for element {elname} in {potential_family}")
    
            # Sorting priority
            if flag_prefer_GW:
                # prioritize GW variants
                priority = ["_sv_GW", "_d_GW", "_GW", "_sv", "_d", f"{elname}"]
            else:
                # prioritize non-GW
                priority = ["_sv", "_d", f"{elname}", "_sv_GW", "_d_GW", "_GW"]
    
            # Pick best match based on substring occurrence
            selected = None
            for key in priority:
                for cand in candidates:
                    if key == elname:
                        # plain element match (no suffix)
                        if cand.endswith(f" {elname}"):
                            selected = cand
                            break
                    elif key in cand:
                        selected = cand
                        break
                if selected:
                    break
    
            if selected is None:
                selected = candidates[0]  # fallback
                print(f"[WARN] No preferred variant found for {elname}, using {selected}")
    
            potential_mapping[elname] = selected.split()[-1]  # full_name e.g. "Cd_sv_GW"
    
        return Str( potential_family ) , Dict( potential_mapping )
    
    # -------------------------------------------------------------------------
    #[6] Build interpolation input namespace (ns_interpolation)
    @staticmethod
    def _build_interpolation_inputs(local_folder_gw_reference: str,
                                    gw_reference_filename_OUTCAR:   str = 'OUTCAR.3',
                                    gw_reference_filename_vasprun:  str = 'vasprun.xml.3',
                                    flag_check_files_existence = True ) -> AttributeDict:
        """
        Prepare the ns_interpolation namespace for VaspmBSEInitScriptWorkChain.

        Supports ONLY the LOCAL GW case:
            - local_gw_reference_folder : Str
            - gw_reference_filename:     List
            - nbandsgw_to_interpolate :  Int

        The REMOTE GW case must be constructed manually by the user,
        because it requires passing an existing RemoteData node.

        Parameters
        ----------
        local_folder_gw_reference : str
            Local absolute path to the folder containing OUTCAR / vasprun.xml.3.
        gw_reference_filename : list[str], optional
            Filenames to pass to the interpolation script.  Default:
            ['OUTCAR.3', 'vasprun.xml.3'].

        Returns
        -------
        AttributeDict
            ns_interpolation namespace (LOCAL-GW branch).
        """

        ns_interp = AttributeDict()
        #LOCAL BRANCH  → User provides a folder path on local filesystem and the name of the OUTCAR file (default OUTCAR.3)
        ns_interp["local_gw_reference_folder"] = Str(local_folder_gw_reference)
        ns_interp["gw_reference_filename"] = gw_reference_filename_OUTCAR
        
        if flag_check_files_existence :  # Ensure directory exists and then if files exist
            if not os.path.isdir(local_folder_gw_reference):
                raise ValueError( f"[ns_interpolation] The provided local GW directory does not exist:{local_folder_gw_reference}")
            outcar_path = os.path.join(local_folder_gw_reference, gw_reference_filename_OUTCAR)
            if not os.path.isfile(outcar_path): 
                raise ValueError( f"[ns_interpolation] The file {outcar_path} GW reference file is missing")
    
        #Extract NBANDSGW from local vasprun.xml.3
        vasprun_path = os.path.join(local_folder_gw_reference, gw_reference_filename_vasprun)
        nbandsgw = Helpers_setup_Workchain._extract_NBANDSGW(vasprun_path)
        ns_interp["nbandsgw_to_interpolate"] = Int(nbandsgw)

        # Interpolation turned on by default
        ns_interp["use_interpolation"] = Bool(True)

        return ns_interp
 
    # -------------------------------------------------------------------------
    #[7] Build BSE-related input namespace (ns_BSE)
    @staticmethod
    def _build_bse_inputs(local_folder_gw_reference: str , 
                          gw_reference_filename_vasprun:  str = 'vasprun.xml.3',
                          ) -> AttributeDict:
        """
        Prepare ns_BSE:
          - static_inverse_diel (Float)
          - screening_parameter (Float)
          - G0W0_gap (Float)
          - optical_energy_window (Float)

        Notes
        -----
        The optical window is currently hard-coded to 3.5 eV,
        but can be made user-adjustable in the future.

        Requires vasprun.xml.3 to exist in the reference GW directory.
        """
        vasprun_path = os.path.join(local_folder_gw_reference, gw_reference_filename_vasprun)
        AEXX, HFSCREEN = Helpers_setup_Workchain._estimate_parameters_from_epsilon_diag( vasprun_path )
        gap = Helpers_setup_Workchain._extract_gap( vasprun_path )

        ns_bse = AttributeDict()
        ns_bse["static_inverse_diel"] = Float(AEXX)
        ns_bse["screening_parameter"] = Float(HFSCREEN)
        ns_bse["G0W0_gap"] = Float(gap)
        ns_bse["optical_energy_window"] = Float(3.5)

        return ns_bse


    # -------------------------------------------------------------------------
    #[8] Pretty print
    @staticmethod
    def _unwrap_aiida(val):
        """Return primitive value for AiiDA data types."""
        try:
            return val.value
        except AttributeError:
            return val

    @staticmethod
    def _format_dict(d, indent=0):
        """Recursively format AttributeDict, Dict, or namespaces as text."""
        sp = "  " * indent
        lines = []
        if isinstance(d, (AttributeDict, dict)):
            for key, val in d.items():
                if isinstance(val, (AttributeDict, dict)):
                    lines.append(f"{sp}- {key}:")
                    lines.extend(Helpers_setup_Workchain._format_dict(val, indent + 1))
                elif hasattr(val, "value"):  # AiiDA data type
                    lines.append(f"{sp}- {key}: {Helpers_setup_Workchain._unwrap_aiida(val)!r}")
                else:
                    lines.append(f"{sp}- {key}: {val}")
        else:
            lines.append(f"{sp}{d}")
        return lines
    
    @staticmethod
    def _build_inputs_summary(inputs: AttributeDict) -> str:
    
        lines = []
        lines.append("========================")
        lines.append(" INPUT SUMMARY")
        lines.append("========================")
    
        # ---- STRUCTURE ----
        if "structure" in inputs:
            st = inputs.structure
            lines.append("\n[STRUCTURE]")
            try:
                formula = st.get_formula()
                n_atoms = len(st.sites)
                lines.append(f"- formula: {formula}")
                lines.append(f"- atoms:   {n_atoms}")
            except Exception:
                lines.append("- (could not read structure metadata)")
    
        # ---- KPOINTS ----
        if "kpoints" in inputs:
            try:
                mesh = inputs.kpoints.get_kpoints_mesh()
                lines.append("\n[KPOINTS]")
                lines.append(f"- mesh: {mesh}")
            except Exception:
                pass
    
        # ---- POTENTIALS ----
        if "potential_family" in inputs:
            lines.append("\[POTENTIALS]")
            lines.append(f"- family: {Helpers_setup_Workchain._unwrap_aiida(inputs.potential_family)}")
    
        if "potential_mapping" in inputs:
            lines.append("- mapping:")
            potmap = inputs.potential_mapping.get_dict()
            for k, v in potmap.items():
                lines.append(f"    - {k}: {v}")
    
        # ---- CODE + OPTIONS ----
        if "code" in inputs:
            lines.append("\n[CODE + SCHEDULER]")
            lines.append(f"- code: {inputs.code}")
    
        if "options" in inputs:
            lines.append("- scheduler options:")
            opts = inputs.options.get_dict()
            lines.extend(Helpers_setup_Workchain._format_dict(opts, indent=1))
    
        # ---- OTHER NAMESPACES ----
        # detect everything that looks like an AiiDA namespace
        lines.append("\n[NAMESPACES]")
    
        for key, val in inputs.items():
            if key in ("structure", "kpoints", "code", "options",
                       "potential_family", "potential_mapping"):
                continue
    
            if isinstance(val, (AttributeDict, dict)) or hasattr(val, "get_dict"):
                lines.append(f"\n[{key}]")
                if hasattr(val, "get_dict"):
                    # AiiDA Dict-like
                    lines.extend(Helpers_setup_Workchain._format_dict(val.get_dict(), indent=0))
                else:
                    # Normal namespace
                    lines.extend(Helpers_setup_Workchain._format_dict(val, indent=0))
    
        lines.append("\n========================")
        lines.append(" END OF INPUT SUMMARY")
        lines.append("========================")
    
        return "\n".join(lines)
    


