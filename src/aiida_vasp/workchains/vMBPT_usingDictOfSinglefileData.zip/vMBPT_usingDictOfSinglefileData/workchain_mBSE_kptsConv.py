import numpy as np
from copy import deepcopy
from aiida.orm import Int, Float, Dict, Bool , List , RemoteData , KpointsData
from aiida.plugins import DataFactory, WorkflowFactory
from aiida.engine  import WorkChain, ToContext , append_, submit, while_ 
from aiida.common.extendeddicts  import AttributeDict


from .workchain_mBSE_base_winterpolation import VaspmBSEInitScriptWorkChain
from .utils_helpers_mBSE import _extract_opticalgap_fromWorkchainNode


from aiida import load_profile
load_profile()

#Miscellaneous utils functions
def _get_kmesh_from_kdensity(latVec , KSPACING , flag_roundInsteadCeil=True ):
        """
        Calculate the k-point mesh dimensions for a given lattice and k-point spacing.
        Args:
          - latVec (array-like): A 3x3 array representing the lattice vectors of the unit cell.
          - KSPACING (in Angstrom^{-1}) represents the smallest allowed spacking between k-points in the BZ; SMALLER values produce DENSER meshes;
            Conversely, The output number of divisions Ni is chosen as the maximum integer that satisfies |b_i| / Ni <= KSPACING
        """

        latVec = np.array( latVec )
        recLatVec= np.zeros((3,3))
        Vol= np.abs( np.dot(latVec[0,:] , np.cross(latVec[1,:],latVec[2,:])) )
        recLatVec[0,:]= np.cross(latVec[1,:],latVec[2,:])  /Vol
        recLatVec[1,:]= np.cross(latVec[2,:],latVec[0,:])  /Vol
        recLatVec[2,:]= np.cross(latVec[0,:],latVec[1,:])  /Vol

        # List of dim=3 with dimensions of the 3 rec.vectors.
        rec_cell_norm = np.array( [np.linalg.norm( recLatVec[x,:]) for x in range(3)] )
        
        #Exact (and thus fractional) K-mesh corresponding to the EXACT KSPACING
        #  For example, for rec_cell_norm = [0.319, 0.319, 0.319] :    
        #  KSPACING = 0.5 -> array([4.0084, 4.0084, 4.0084])
        #  KSPACING = 0.3 -> array([6.6807, 6.6807, 6.6807])
        Kmesh_ideal_fractional = np.array(rec_cell_norm) * 2*np.pi / KSPACING

        if flag_roundInsteadCeil:   Kmesh = [ max(1.0,np.round(k)) for k in Kmesh_ideal_fractional ]
        else:                       Kmesh = np.ceil( Kmesh_ideal_fractional )
        Kmesh = np.array( Kmesh ).astype(int)
        return Kmesh

def _get_kspacing_from_kmesh(latVec, kmesh): 
        #k-mesh = 2pi * |bi|/ k-density  ->DataFactory('core.array.kpoints')
        kmesh_tmp = deepcopy( kmesh )
        latVec = np.array( latVec )
        recLatVec= np.zeros((3,3))
        Vol= np.abs( np.dot(latVec[0,:] , np.cross(latVec[1,:],latVec[2,:])) )
        recLatVec[0,:]= np.cross(latVec[1,:],latVec[2,:])  /Vol
        recLatVec[1,:]= np.cross(latVec[2,:],latVec[0,:])  /Vol
        recLatVec[2,:]= np.cross(latVec[0,:],latVec[1,:])  /Vol

        rec_cell_norm = [np.linalg.norm( recLatVec[x,:]) for x in range(3)]    
        return [2*np.pi * rec_cell_norm[idx] / kmesh_tmp[idx] for idx in range(len(rec_cell_norm)) ]
        


class VaspmBSEKptsConvWorkChain(WorkChain):
    _next_workchain = WorkflowFactory('vasp.vasp')

    @classmethod
    def define(cls, spec):
            super(VaspmBSEKptsConvWorkChain , cls).define(spec)

            spec.expose_inputs(cls._next_workchain          , exclude=('kpoints','parameters','settings','potential_family','potential_mapping')) 
            spec.expose_inputs(VaspmBSEInitScriptWorkChain  , exclude=('kpoints') ) 
             
            spec.input( 'ns_kpoints.convergence_threshold'       , valid_type=Float , required=False , default=lambda:Float(0.1), help="minimum converge value in eV" ) 
            spec.input( 'ns_kpoints.kMesh.startingValue'         , valid_type= KpointsData , required=False , help="Starting k-mesh for the k-point density convergence If not specified, a k-mesh based on the density kDensity.startingValue will be used" )
            spec.input( 'ns_kpoints.kMesh.maxValue'              , valid_type= KpointsData , required=False , help="Maximum k-mesh for the k-point density convergence. If not specified, a k-mesh based on the density kDensity.maxValue will be used" ) 
            kpoints_step_defaultvalue = DataFactory('core.array.kpoints')() ; kpoints_step_defaultvalue.set_kpoints_mesh([1,1,1])
            spec.input( 'ns_kpoints.kMesh.step'                  , valid_type= KpointsData , required=False , default=lambda:kpoints_step_defaultvalue, help="Step size for the k-point mesh." ) 

            spec.input('ns_opt_converge.use_Gradient'     , valid_type=Bool , required=False , default=lambda:Bool(True)  )
        
            #Optional pass-through (kept for symmetry with G0W0; currently not consumed explicitly by the base chain)
            spec.input('ns_reference.DFTgr_RemoteData', valid_type=RemoteData, required=False)
       
        
            spec.output( 'kmesh_converged' , valid_type= KpointsData , required=True)
            spec.output( 'optical_gap'     , valid_type= Float , required=False)
            
            spec.exit_code(403,'NODE_HAS_NO_MBSE_OUTPUT' , message='The workchain node has no opticaltransition output - please check that the calculation has completed correctly.')
            spec.exit_code(404,'CONVERGENCE_NOT_FOUND'   , message='Convergence has not been reached; please relax the threshold / increase the range studied / check the calculations.')
            spec.exit_code(405,'NOT_IMPLEMENTED'         , message='as the error say')
            

            
            
            spec.outline(
                cls.initialize,
                while_(cls.monitor_convergence)(
                     cls.prepare_run_mBSE,
                ),
                cls.elaborate_results     
            )
        
    def initialize(self):
        self.ctx.control = AttributeDict() ; 
        
        self.ctx.control['kmesh_converged'] = None ; self.ctx.control['kdensity_converged'] = None ; 
        self.ctx.WC_MBPT = []

            
        ##[ The Kpoint part ]
        #There are two possible ways to control the convergence:
        # 1) through the k-mesh : in this case, both the kmesh.startingValue and kmesh.maxValue of kMesh must be specified; only the step is optional (default=1)
        # 2) through the k-point density : this case is activated only if BOTH kMesh.startingValue and kMesh.maxValue are NOT specified; 
        #                                  and is more flexible, as there are no mandatory values, all values have a default values
        #    Two additional notes:
        #    - if kmesh.startingValue is specified, and not kmesh.maxValue that kmesh is used as starting k-mesh, but the increase of the k-mesh is done through the k-point density 
        #      and not through the k-mesh step
        #    - in this second case, the minimum_constraint of kDensity is always considered, i.e. the startingValue of kDensity is automatically increased if it is < minimum_constraint
  
        self.ctx.control.iteration_counter = -1
        self.ctx.control['control_way'] = ''  #can be 'kmesh' or 'kdensity' depending on how the convergence is controlled
        self.ctx.control['kmesh']       = [] #List of k-meshes to be tested

        
        ##[1]Now Let's check which of the two ways is used
        if ('kMesh' in self.inputs.ns_kpoints) and ('startingValue' in self.inputs.ns_kpoints.kMesh) and ('maxValue' in self.inputs.ns_kpoints.kMesh):
            self.ctx.control['control_way'] = 'kmesh'
            str_log = ("\n [Initializing K-points convergence]"+"\n > Both kmesh.startingValue and kmesh.maxValue are specified"+
                       "\n   -> Controlling k-point convergence through k-mesh."+
                       "\n   > kMesh.startingValue: " + str(self.inputs.ns_kpoints.kMesh.startingValue.get_kpoints_mesh()[0] )+
                       "\n   > kMesh.maxValue: " + str(self.inputs.ns_kpoints.kMesh.maxValue.get_kpoints_mesh()[0] ))
            
            
        #[2] Initialize the starting k-mesh
        if ('kMesh' in self.inputs.ns_kpoints) and ('startingValue' in self.inputs.ns_kpoints.kMesh) :
            kmesh_start    = self.inputs.ns_kpoints.kMesh.startingValue.get_kpoints_mesh()[0]
            str_log = ("\n [Initializing K-points convergence]"+"\n > Starting k-mesh is specified by the user ("+str(self.inputs.ns_kpoints.kMesh.startingValue.get_kpoints_mesh()[0] )+") - using as starting k-mesh")

        
        ##[2] Generate the other k-meshes to be tested 
        if self.ctx.control['control_way'] == 'kmesh':
            #Create two lists for the optical gaps variables which will be checked:
            self.ctx.control['optgap_trans_energies'] , self.ctx.control['optgap_trans_oscstr'] = [] , []
            #First append the starting one:
            self.ctx.control['kmesh'].append(    np.array(kmesh_start    , dtype=int)   )
            #And generate the first candidate:
            tmp_new_candidate_kmesh =  self.ctx.control['kmesh'][-1] + np.array(self.inputs.ns_kpoints.kMesh.step.get_kpoints_mesh()[0] , dtype=int )
            #Then check that candidate and generate new candidates
            while np.any(tmp_new_candidate_kmesh < self.inputs.ns_kpoints.kMesh.maxValue.get_kpoints_mesh()[0] ):
                 self.ctx.control['kmesh'].append(    np.array(tmp_new_candidate_kmesh , dtype=int)  )
                 tmp_new_candidate_kmesh =  self.ctx.control['kmesh'][-1] + np.array(self.inputs.ns_kpoints.kMesh.step.get_kpoints_mesh()[0] , dtype=int )
            str_log = str_log + ( "\n   > kmesh list:    "+str(self.ctx.control['kmesh'])    )
            
        if self.ctx.control['control_way'] != 'kmesh':
            return self.exit_codes.NOT_IMPLEMENTED           
            
        self.report(str_log)

    def prepare_run_mBSE(self):
        # Build inputs for the base workchain
        self.ctx.inputs_mBSEbase = AttributeDict()
        self.ctx.inputs_mBSEbase.update(self.exposed_inputs(VaspmBSEInitScriptWorkChain))
        #The following spec.inputs of the VaspmBSEInitScriptWorkChain are exposed, and thus updated here
        #and do not need therefore to be handled explicitly:    
        #    ns_parameters.encut - ns_parameters.nbands - ns_parameters.magnetic_moment_onsite
        #    ns_interpolation.G0W0_reference - ns_interpolation.remote_initscript
        #    ns_interpolation.local_initscript - ns_interpolation.nbandsgw_to_interpolate
        #    ns_BSE.static_inverse_diel - ns_BSE.screening_parameter - ns_BSE.energy_window
        #    ns_BSE.G0W0_gap - ns_BSE.OMEGAMAX - ns_BSE_NBANDSV - ns_BSE_NBANDSO
        #    scissor
        self.ctx.inputs_mBSEbase.clean_workdir = Bool(False)            
        self.ctx.inputs_mBSEbase.potential_family  = self.inputs.potential_family
        self.ctx.inputs_mBSEbase.potential_mapping = self.inputs.potential_mapping
        
        #Finally, kpoint related stuff        
        self.ctx.inputs_mBSEbase.kpoints = DataFactory('core.array.kpoints')()
        self.ctx.inputs_mBSEbase.kpoints.set_kpoints_mesh(  self.ctx.control['kmesh'][self.ctx.control.iteration_counter] )
           
        # Reference WAVECAR/CHGCAR if user provided (optional)
        # Optional: allow future use of ns_reference (currently unused by base chain)
        if 'ns_reference' in self.inputs and 'DFTgr_RemoteData' in self.inputs.ns_reference:
            pass  # kept for symmetry; not altering the base workchain behavior
                     
        self.report("\n [wkc_KptsConv][DFT+mBSE calc - NonSpinPolarized - From scratch]\n  > Lauching DFT+mBSE(NonSpinPolarized) using VaspmBSEInitScriptWorkChain on k-mesh "
                            +np.array2string(   self.ctx.control['kmesh'][self.ctx.control.iteration_counter] , separator=" , ").replace('\n', '')+"\n")  
        running_mBSEbase = self.submit(VaspmBSEInitScriptWorkChain , **self.ctx.inputs_mBSEbase) 
        return ToContext(WC_MBPT=append_(running_mBSEbase))
         
    def monitor_convergence_TEST(self): 
        self.ctx.control.iteration_counter += 1
        if self.ctx.control.iteration_counter == 1: return False
        else: return True
    
    def monitor_convergence(self): 
        # #counter starts at -1 and changes BEFORE a calc is launched
        # #1°control: counter starts=-1  -> [conv. check] -> increased to 0 -> launched 1° G0W0/mBSE
        # #2°control: counter starts= 0  -> [conv. check] -> increased to 1 -> launched 2° G0W0/mBSE
        # #3°control: counter starts= 1  -> [conv. check] -> increased to 2 -> launched 3° G0W0/mBSE

        #Initialize - Define a AttributeDict which will be used internally for this execution of the monitor_convergence
        #It's used to group in a single dict the relevant flags/values.
        self.ctx.monitor = AttributeDict()
        self.ctx.monitor.flag_is_converged = False
        self.ctx.monitor.control_way       = deepcopy( self.ctx.control['control_way'] )  # 'kmesh' or 'kdensity' 
        self.ctx.monitor.total_num_kmesh = len(self.ctx.control['kmesh'])
        self.ctx.monitor.thr      = self.inputs.ns_kpoints.convergence_threshold.value
        #Spin related variables
        self.ctx.monitor.has_spin      = ('magnetic_moment_onsite' in self.inputs['ns_parameters'])
        self.ctx.monitor.spin_channels = ['spinUp', 'spinDw'] if self.ctx.monitor.has_spin else ['spinUp']
        #Define minimum number of calculations required before convergence checks
        #The convergence based on k-mesh uses only 2 (the gaps from 2 consecutive k-meshes); the one based on k-density 3 for numerical stability.
        self.ctx.monitor.min_num_calcs_required_for_conv = 2 
        
        #Initialize - Logging header
        str_log = ( f"\n [wkc_KptsConv][monitor_convergence] iteration_counter={self.ctx.control.iteration_counter}"
                    f" before launching MBPT calculation num={self.ctx.control.iteration_counter+1}"
                    "\n  Remember : iteration_counter starts at (i-1)th -> [conv. check] -> increased to i-th -> launched i-th G0W0/mBSE" )
        
        
        ##[DECISION.BLOCK - 1] Early exit if not enough calculations yet
        #Counter starts at -1 ; it's increased AFTER the convergence check + but BEFORE launching the calculation
        #The counter increase is the LAST thing done before returning; thus:
        #  1°control: counter starts=-1  -> [conv. check] -> increased to 0 -> launched 1° G0W0/mBSE
        #  2°control: counter starts= 0  -> [conv. check] -> increased to 1 -> launched 2° G0W0/mBSE
        #  3°control: counter starts= 1  -> [conv. check] -> increased to 2 -> launched 3° G0W0/mBSE
        #  4°control: counter starts= 2  -> convergence is checked; if not changed to 3 -> launched 3° G0W0/mBSE
        #  [..]
        #We have N k-density to test:
        #  N-1° control: counter starts= N-3 -> changed to N-2 -> launched N-1° G0W0/mBSE
        #  N°   control: counter starts= N-2 -> changed to N-1 -> launched N° G0W0/mBSE
        #  N+1° control  counter starts= N-1 -> exit with error  
        #[k-mesh case] Consider that the counter is increased BEFORE launching the calculation, and starts at -1; 
        #                so when counter=0 here we are at the conv.check of the second iteration, before launching the calculation
        #                and we have therefore to return True in order to continue and perform the second calculation
        #                at the beginning of the third iteration, (before the third calculation) self.ctx.control.iteration_counter will be == 1
        #                and remember that self.ctx.monitor.min_num_calcs_required_for_conv = 2 for the k-mesh
        if self.ctx.control.iteration_counter < (self.ctx.monitor.min_num_calcs_required_for_conv - 1):
            str_log += ( f"\n  > Not enough calculations to perform convergence check "
                         f"(need ≥{self.ctx.monitor.min_num_calcs_required_for_conv}); launching next {self.ctx.monitor.control_way}-based calculation.\n" )
            self.report(str_log)   
            self.ctx.control.iteration_counter += 1    
            if self.ctx.control.iteration_counter >=  self.ctx.monitor.total_num_kmesh:  # Safety: check we have not exhausted available meshes
                self.report(f"\n  > Reached maximum number of {self.ctx.monitor.control_way} points to be tested; convergence not found.\n")
                return self.exit_codes.CONVERGENCE_NOT_FOUND
            return True   # Continue launching next calculation

        #[DETERMINING self.ctx.monitor.flag_is_converged FOR THE kmesh control_way]
        if self.ctx.monitor.control_way == 'kmesh':
            for wc in self.ctx.WC_MBPT:
                if 'opticaltransitions' in wc.outputs:
                    tmp_opttran , tmp_osctr = _extract_opticalgap_fromWorkchainNode(wc)
                    self.ctx.control['optgap_trans_energies'].append( tmp_opttran )
                    self.ctx.control['optgap_trans_oscstr'].append( tmp_osctr )
                else:
                    return self.exit_codes.NODE_HAS_NO_MBSE_OUTPUT
    
            delta = abs(self.ctx.control['optgap_trans_energies'][-1] - self.ctx.control['optgap_trans_energies'][-2])
            self.ctx.monitor.flag_is_converged = delta < self.inputs.ns_kpoints.convergence_threshold.value
            str_log += (f"Δ(optical gap) between last two meshes = {delta:.4f} eV (thr={self.inputs.ns_kpoints.convergence_threshold.value})")

        ##[DECISION.BLOCK - 2] Final control logic --------------------------------------------
        # Decide whether to continue or stop based on convergence.
        # The max-number-of-calculations check is already handled in DECISION.BLOCK - 1.
        if bool(self.ctx.monitor.flag_is_converged) :
            str_log += (f"\n  --> convergence REACHED at index {self.ctx.control.iteration_counter}\n")
            self.report(str_log)
            
            self.ctx.control['kmesh_converged'] = DataFactory('core.array.kpoints')()
            self.ctx.control['kmesh_converged'].set_kpoints_mesh(   self.ctx.control['kmesh'][self.ctx.control.iteration_counter] )
            return False  # stop workflow
        else:
            self.ctx.control.iteration_counter += 1
            str_log += ("\n  --> convergence NOT reached - continuing!")
            self.report(str_log)              
            return True



            
    def elaborate_results(self):
        kmesh_final = np.array(self.ctx.control['kmesh'][self.ctx.control.iteration_counter], dtype=int)
        kmesh_conv = self.ctx.control.get('kmesh_converged', None)   
        node_kpoints = DataFactory('core.array.kpoints')()
        if kmesh_conv is not None:  node_kpoints = kmesh_conv
        else:                       node_kpoints.set_kpoints_mesh(kmesh_final)
        node_kpoints.store()
        self.out('kmesh_converged', node_kpoints )
    
        if self.ctx.control['optgap_trans_energies']:
            self.out('optical_gap', Float(self.ctx.control['optgap_trans_energies'][-1]))

     
       




